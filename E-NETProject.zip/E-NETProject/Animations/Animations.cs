﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace ElectronicNET
{
    internal class Animation
    {
        private Storyboard storyboard = new Storyboard();

        public async void MoveAnimation(DependencyObject Object, Thickness Get, Thickness Set)
        {
            ThicknessAnimation thicknessAnimation = new ThicknessAnimation();
            thicknessAnimation.From = new Thickness?(Get);
            thicknessAnimation.To = new Thickness?(Set);
            thicknessAnimation.Duration = (Duration)TimeSpan.FromMilliseconds(1000.0);
            thicknessAnimation.EasingFunction = this.Easing;
            ThicknessAnimation Animation = thicknessAnimation;
            Storyboard.SetTarget((DependencyObject)Animation, Object);
            Storyboard.SetTargetProperty((DependencyObject)Animation, new PropertyPath((object)FrameworkElement.MarginProperty));
            this.storyboard.Children.Add((Timeline)Animation);
            this.storyboard.Begin();
            await Task.Delay(100);
            this.storyboard.Children.Remove((Timeline)Animation);
            Animation = (ThicknessAnimation)null;
        }

        public async void OpacityAnimation(
          DependencyObject Object,
          double Get,
          double Set,
          double Duration)
        {
            DoubleAnimation Animation = new DoubleAnimation();
            Animation.EasingFunction = this.Easing;
            Animation.Duration = (Duration)TimeSpan.FromMilliseconds(Duration);
            Animation.From = new double?(Get);
            Animation.To = new double?(Set);
            Storyboard.SetTarget((DependencyObject)Animation, Object);
            Storyboard.SetTargetProperty((DependencyObject)Animation, new PropertyPath((object)UIElement.OpacityProperty));
            this.storyboard.Children.Add((Timeline)Animation);
            this.storyboard.Begin();
            await Task.Delay(1000);
            this.storyboard.Children.Remove((Timeline)Animation);
            Animation = (DoubleAnimation)null;
        }

        public async void WidthAnimation(
          DependencyObject Object,
          double Get,
          double Set,
          double Duration)
        {
            DoubleAnimation Animation = new DoubleAnimation();
            Animation.EasingFunction = this.Easing;
            Animation.Duration = (Duration)TimeSpan.FromMilliseconds(Duration);
            Animation.From = new double?(Get);
            Animation.To = new double?(Set);
            Storyboard.SetTarget((DependencyObject)Animation, Object);
            Storyboard.SetTargetProperty((DependencyObject)Animation, new PropertyPath((object)FrameworkElement.WidthProperty));
            this.storyboard.Children.Add((Timeline)Animation);
            this.storyboard.Begin();
            await Task.Delay(100);
            this.storyboard.Children.Remove((Timeline)Animation);
            Animation = (DoubleAnimation)null;
        }

        private IEasingFunction Easing { get; set; }

        public Animation()
        {
            QuadraticEase quadraticEase = new QuadraticEase();
            quadraticEase.EasingMode = EasingMode.EaseInOut;
            this.Easing = (IEasingFunction)quadraticEase;
            base.MemberwiseClone();
        }
    }
}
