﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace ElectronicNET
{
	public static class Miscellaneous
	{
		public static T GetTemplateItem<T>(this Control elem, string name)
		{
			object obj;
			if ((obj = elem.Template.FindName(name, elem)) is T)
			{
				return (T)((object)obj);
			}
			return default(T);
		}
	}
}
