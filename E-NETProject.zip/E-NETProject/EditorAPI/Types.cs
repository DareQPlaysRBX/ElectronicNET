﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectronicNET
{
	public enum Types
	{
		Class,
		Color,
		Constructor,
		Enum,
		Field,
		File,
		Folder,
		Function,
		Interface,
		Keyword,
		Method,
		Module,
		Property,
		Reference,
		Snippet,
		Text,
		Unit,
		Value,
		Variable,
		None
	}
}
