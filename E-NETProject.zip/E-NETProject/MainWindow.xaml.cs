﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FluxAPI;

namespace ElectronicNET
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IComponentConnector
    {
        private WebViewA EditorSource;
        private int TabCount;
        private TabItem TabSettings;
        private ScrollViewer EditorScroll;
        private Animation Animate = new Animation();
        FluxAPI.API Module = new FluxAPI.API();

        public MainWindow()
        {
            InitializeComponent();
            ListRefresh();
            NewTab("Home Tab");
            this.MainTabControl.Loaded += delegate (object s, RoutedEventArgs f)
            {
                this.MainTabControl.GetTemplateItem<Button>("addTab").Click += delegate (object e, RoutedEventArgs x)
                {
                    this.NewTab("Untitled");
                };
                this.EditorScroll = this.MainTabControl.GetTemplateItem<ScrollViewer>("TabScrollViewer");
            };
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        public TabItem NewTab(string title)
        {
            this.EditorSource = new WebViewA();
            ((HwndHost)this.EditorSource).UpdateWindowPos();
            TextBox textBox1 = new TextBox();
            textBox1.Text = title;
            textBox1.IsEnabled = false;
            textBox1.TextWrapping = TextWrapping.NoWrap;
            textBox1.IsHitTestVisible = false;
            textBox1.Background = (Brush)Brushes.Transparent;
            textBox1.BorderBrush = (Brush)Brushes.Transparent;
            textBox1.Foreground = (Brush)Brushes.White;
            textBox1.FontFamily = new FontFamily("Bahschrift");
            textBox1.FontSize = 12.0;
            TextBox textBox2 = textBox1;
            TabItem tabItem = new TabItem();
            tabItem.Style = this.TryFindResource((object)"TabItem") as Style;
            tabItem.Content = (object)this.EditorSource;
            tabItem.Header = (object)textBox2;
            tabItem.AllowDrop = true;
            this.TabSettings = tabItem;
            ((Selector)this.MainTabControl).SelectedIndex = ((ItemsControl)this.MainTabControl).Items.Add((object)this.TabSettings);
            tabItem.MouseDown += delegate (object sender, MouseButtonEventArgs e)
            {
                if (e.OriginalSource is Border)
                {
                    if (e.RightButton == MouseButtonState.Pressed)
                    {
                        this.MainTabControl.Items.Remove(tabItem);
                        return;
                    }
                }
            };
            tabItem.MouseMove += this.MoveTab;
            tabItem.Drop += this.DropTab;
            ++this.TabCount;
            return this.TabSettings;
        }

        private void ScrollTabs(object sender, MouseWheelEventArgs e)
        {
            this.EditorScroll.ScrollToHorizontalOffset(this.EditorScroll.HorizontalOffset + (double)(e.Delta / 10));
        }

        private void MoveTab(object sender, MouseEventArgs e)
        {
            TabItem tabItem = e.Source as TabItem;
            if (tabItem == null)
            {
                return;
            }
            if (Mouse.PrimaryDevice.LeftButton == MouseButtonState.Pressed)
            {
                if (VisualTreeHelper.HitTest(tabItem, Mouse.GetPosition(tabItem)).VisualHit is Button)
                {
                    return;
                }
                DragDrop.DoDragDrop(tabItem, tabItem, DragDropEffects.Move);
            }
        }

        private void DropTab(object sender, DragEventArgs e)
        {
            TabItem tabItem = e.Source as TabItem;
            if (tabItem != null)
            {
                TabItem tabItem2 = e.Data.GetData(typeof(TabItem)) as TabItem;
                if (tabItem2 != null)
                {
                    if (!tabItem.Equals(tabItem2))
                    {
                        TabControl tabControl = tabItem.Parent as TabControl;
                        int insertIndex = tabControl.Items.IndexOf(tabItem2);
                        int num = tabControl.Items.IndexOf(tabItem);
                        tabControl.Items.Remove(tabItem2);
                        tabControl.Items.Insert(num, tabItem2);
                        tabControl.Items.Remove(tabItem);
                        tabControl.Items.Insert(insertIndex, tabItem);
                        tabControl.SelectedIndex = num;
                    }
                    return;
                }
            }
        }

        public void ListRefresh()
        {
            this.ListofScripts.Items.Clear();
            foreach (FileInfo fileInfo in new DirectoryInfo("./scripts").GetFiles("*.txt"))
            {
                this.ListofScripts.Items.Add(fileInfo.Name);
            }
            foreach (FileInfo fileInfo2 in new DirectoryInfo("./scripts").GetFiles("*.lua"))
            {
                this.ListofScripts.Items.Add(fileInfo2.Name);
            }
        }

        public WebViewA GetCurrent()
        {
            TabItem tabItem = this.MainTabControl.SelectedItem as TabItem;
            return ((tabItem != null) ? tabItem.Content : null) as WebViewA;
        }

        private void MainGrid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            
        }

        private void ScriptHubButton_Click(object sender, RoutedEventArgs e)
        {
            Light2.Visibility = Visibility.Visible;
            Light1.Visibility = Visibility.Hidden;
            Light1.Opacity = 0;
            Animate.OpacityAnimation((DependencyObject)Light2, 0.0, 100.0, 5000.0);
        }

        private void HomeButton_Click(object sender, RoutedEventArgs e)
        {
            Light1.Visibility = Visibility.Visible;
            Light2.Visibility = Visibility.Hidden;
            Light2.Opacity = 0;
            Animate.OpacityAnimation((DependencyObject)Light1, 0.0, 100.0, 5000.0);
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            
        }

        private void TopGrid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            base.DragMove();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void InjectButton_MouseEnter(object sender, MouseEventArgs e)
        {
            Light4.Visibility = Visibility.Visible;
            Light4.Opacity = 0;
            Animate.OpacityAnimation((DependencyObject)Light4, 0.0, 100.0, 5000.0);
        }

        private void InjectButton_MouseLeave(object sender, MouseEventArgs e)
        {
            Light4.Opacity = 1;
            Animate.OpacityAnimation((DependencyObject)Light4, 100.0, 0.0, 5000.0);
            Light4.Visibility = Visibility.Hidden;
        }

        private void InjectButton_Click(object sender, RoutedEventArgs e)
        {
            Module.Inject();
        }

        private void SettingsButton_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void SettingsButton_MouseEnter(object sender, MouseEventArgs e)
        {
            Light3.Visibility = Visibility.Visible;
            Light3.Opacity = 0;
            Animate.OpacityAnimation((DependencyObject)Light3, 0.0, 100.0, 5000.0);
        }

        private void SettingsButton_MouseLeave(object sender, MouseEventArgs e)
        {
            Light3.Opacity = 1;
            Animate.OpacityAnimation((DependencyObject)Light3, 100.0, 0.0, 5000.0);
            Light3.Visibility = Visibility.Hidden;
        }

        private void ClearButton_MouseEnter(object sender, MouseEventArgs e)
        {
            Light5.Visibility = Visibility.Visible;
            Light5.Opacity = 0;
            Animate.OpacityAnimation((DependencyObject)Light5, 0.0, 100.0, 5000.0);
        }

        private void ClearButton_MouseLeave(object sender, MouseEventArgs e)
        {
            Light5.Opacity = 1;
            Animate.OpacityAnimation((DependencyObject)Light5, 100.0, 0.0, 5000.0);
            Light5.Visibility = Visibility.Hidden;
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            bool flag = this.GetCurrent() == null;
            if (!flag)
            {
                this.GetCurrent().SetText("");
            }
        }

        private void ExecuteButton_MouseEnter(object sender, MouseEventArgs e)
        {
            Light6.Visibility = Visibility.Visible;
            Light6.Opacity = 0;
            Animate.OpacityAnimation((DependencyObject)Light6, 0.0, 100.0, 5000.0);
        }

        private void ExecuteButton_MouseLeave(object sender, MouseEventArgs e)
        {
            Light6.Opacity = 1;
            Animate.OpacityAnimation((DependencyObject)Light6, 100.0, 0.0, 5000.0);
            Light6.Visibility = Visibility.Hidden;
        }

        private async void ExecuteButton_Click(object sender, RoutedEventArgs e)
        {
            bool flag = this.GetCurrent() != null;
            if (flag)
            {
                Module.Execute(await((WebViewA)((TabControl)this.MainTabControl).SelectedContent).GetText());
            }
        }

        private async void HideListButton_Click(object sender, RoutedEventArgs e)
        {
            if (LeftGrid.Width == 142)
            {
                Animate.MoveAnimation((DependencyObject)this.LeftGrid, new Thickness(18, 77, 520, 19), new Thickness(18, 395, 520, -299));
                Animate.MoveAnimation((DependencyObject)this.EditorGrid, new Thickness(165, 77, 18, 19), new Thickness(18, 77, 18, 19));
                await Task.Delay(250);
                Animate.WidthAnimation((DependencyObject)this.LeftGrid, 142.0, 0.0, 400.0);
            }
            else if (LeftGrid.Width == 0)
            {
                Animate.WidthAnimation((DependencyObject)this.LeftGrid, 0.0, 142.0, 400.0);
                await Task.Delay(50);
                Animate.MoveAnimation((DependencyObject)this.EditorGrid, new Thickness(18, 77, 18, 19), new Thickness(165, 77, 18, 19));
                Animate.MoveAnimation((DependencyObject)this.LeftGrid, new Thickness(18, 395, 520, -299), new Thickness(18, 77, 520, 19));
            }
        }

        private void HideListButton_MouseEnter(object sender, MouseEventArgs e)
        {
            Light7.Visibility = Visibility.Visible;
            Light7.Opacity = 0;
            Animate.OpacityAnimation((DependencyObject)Light7, 0.0, 100.0, 5000.0);
        }

        private void HideListButton_MouseLeave(object sender, MouseEventArgs e)
        {
            Light7.Opacity = 1;
            Animate.OpacityAnimation((DependencyObject)Light7, 100.0, 0.0, 5000.0);
            Light7.Visibility = Visibility.Hidden;
        }

        private void ListofScripts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool flag = this.ListofScripts.SelectedIndex != -1;
            bool flag2 = flag;
            if (flag2)
            {
                this.GetCurrent().SetText(File.ReadAllText("scripts\\" + this.ListofScripts.SelectedItem.ToString()));
                ListRefresh();
            }
        }
    }
}
